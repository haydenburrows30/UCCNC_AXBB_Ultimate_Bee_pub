V1.2115 4 Axis Screenset Install Instructions
#############################################

1: - Copy and replace Default2019 folder to C:\UCCNC\Flashscreen\BMP\
2: - Copy and replace Macro folder to C:\UCCNC\Profiles\
3: - Copy and replace Default2019 to C:\UCCNC\Screens\
4: - Open Default.pro in Notepad ( or any text editor ) File location is C:\UCCNC\Profiles\Default.pro
5: - Change second line to "mainscreenfilename=Default2019" ( do not include "" )

Note: If you want to save your settings just follow the steps 1 to 4..... do not install new UCCNC SOFTWARE


ENJOY!
V1.2115 4 Axis Screenset Install Instructions
#############################################

1: - Copy and replace Default2019 folder to C:\UCCNC\Flashscreen\BMP\
2: - Copy Default2019 4 Axis.ssf to C:\UCCNC\Screens\
3: - Open Default.pro in Notepad ( or any text editor ) File location is C:\UCCNC\Profiles\Default.pro
4: - Change second line from "mainscreenfilename=Default2019" to "mainscreenfilename=Default2019 4 Axis" ( do not include "" )